# OpenClaw 环境地质学案例形成性反馈

教师控制的《环境地质学》树坪滑坡案例教学工具草案。保留2个Agent和3个Skill，服务66人课程的材料检查、六维专业反馈、教师反馈复核和匿名汇总。计划于2026年10月30日课堂实施，实际参加人数与成效随后据记录补入。

当前版本为0.1.1-draft。已完成本地确定性程序、模拟批处理和历史版配置校验；未部署课程Gateway，未调用OpenClaw真实模型，未完成课堂实施或教师专业校准。技术完成情况见 [测试报告](docs/test-report_20261016_2038.md)，不能把模拟结果作为结题教学成效。

## 5分钟离线试跑

需要Python 3.10或以上，无第三方依赖。在仓库根目录执行：

```bash
python3 -m unittest discover -s tests -v
python3 -m egtool demo --out /tmp/eg-demo-NEW
```

第二条生成66份明确标记的模拟报告和模拟教师核查。将生成的 `intake_YYYYMMDD_HHMM.json` 的实际路径填入：

```bash
python3 -m egtool batch --inputs /tmp/eg-demo-NEW/submissions --intake /tmp/eg-demo-NEW/intake_YYYYMMDD_HHMM.json --out /tmp/eg-run-NEW
```

默认backend为mock，不调用模型、不发消息。输入与输出目录必须使用新的路径；已有结果不会被覆盖。运行输出包含逐生gate、反馈JSON与Markdown、教师端复核JSON与Markdown、运行日志和六维汇总CSV。模拟教师端全部保持待人工复核。

## 目录

| 路径 | 内容 |
|---|---|
| skills/ | 三个可独立复制安装的Skill，含规则、Schema、量规、来源和辅助校验脚本 |
| agents/ | 两个角色的AGENTS.md与SOUL.md，分版本的配置示例 |
| case-study/ | 树坪案例任务、来源与许可索引、量规、模板、原创模拟数据 |
| schemas/ | 提交、教师材料核查、gate、反馈、教师复核与运行日志协议 |
| egtool/ | 只依赖标准库的材料门槛、协议检查、批处理、配置准备和呈现程序 |
| tests/ | 可复现的技术边界测试与专业行为验收场景 |
| docs/ | 操作、权限、版本兼容、证据对齐、课堂实施及结题清单 |

## 教师实际使用

1. 阅读 [使用手册](docs/teacher-manual_20261016_2038.md) 与 [来源及版本状态](docs/source-authority_20261016_2038.md)。
2. 教师核实原始材料和证据来源，学生材料只保存在公共仓库之外。学号映射表另存，不进入模型或公开包。
3. 按 [兼容说明](docs/openclaw-compatibility_20261016_2038.md) 准备独立profile；正式部署须取得用户确认。不要把示例配置直接覆盖现有OpenClaw配置。
4. 先做合成案例的真实模型小样本验收，再处理真实材料；教师签认后发放反馈。
5. 留存初稿、反馈、修订说明、修订稿、教师终审及独立测评。问卷是学情与接受度证据，不能单独证明能力提升。

本轮本机实测版本为OpenClaw 2026.7.1-2 (0790d9f)。`agents.list`示例通过该版本原生配置校验；`agents.entries`只面向当前在线文档，未在新版运行时验证。不能把当前文档当作所有历史版本的配置规范。

## 许可与公开边界

自编代码与材料建议使用MIT，正式公开前由负责人确认。论文和数据各自许可见 [第三方说明](THIRD_PARTY_NOTICES.md)。真实监测资料只给申请与来源指针，当前包没有它们的数值。全部内置数值序列明确为模拟。学校原件、问卷截图、学生作业、身份对应表、密钥、认证库和本机配置不包含在公开包中。
