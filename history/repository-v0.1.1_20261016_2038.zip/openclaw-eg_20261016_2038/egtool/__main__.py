import argparse
from pathlib import Path
import sys
from .contracts import ContractError
from .pipeline import make_demo, stage, run_batch, OpenClawBackend


def main():
    p=argparse.ArgumentParser(description="教师控制的环境地质学反馈工具；默认不调用真实模型。")
    sp=p.add_subparsers(dest="cmd",required=True)
    d=sp.add_parser("demo");d.add_argument("--out",required=True);d.add_argument("--count",type=int,default=66)
    st=sp.add_parser("stage");st.add_argument("--out",required=True);st.add_argument("--layout",choices=["legacy-list","current-entries"],required=True);st.add_argument("--model",required=True)
    b=sp.add_parser("batch");b.add_argument("--inputs",required=True);b.add_argument("--intake",required=True);b.add_argument("--out",required=True)
    b.add_argument("--backend",choices=["mock","openclaw"],default="mock");b.add_argument("--only",help="仅在新运行目录重试逗号分隔的匿名编号")
    b.add_argument("--executable");b.add_argument("--config");b.add_argument("--approval-file");b.add_argument("--confirmed-live-use",action="store_true")
    a=p.parse_args()
    try:
        if a.cmd=="demo":
            print(make_demo(a.out,a.count));return
        if a.cmd=="stage":
            print(stage(a.out,a.layout,a.model));return
        backend=None
        if a.backend=="openclaw":
            if not all([a.executable,a.config,a.approval_file]):raise ContractError("LIVE_PROFILE_ARGUMENTS_REQUIRED")
            backend=OpenClawBackend(a.executable,a.config,a.approval_file,a.confirmed_live_use)
        r=run_batch(a.inputs,a.intake,a.out,backend,a.only.split(",") if a.only else None)
        print(f"backend={r['backend']} simulated={r['is_simulated']} attempted={r['attempted']} valid_teacher_outputs={r['valid_teacher_model_reviews']} human_final=0")
        if r['pending_or_failed']:sys.exit(2)
    except (ContractError,OSError,ValueError) as e:
        print("停止："+str(e),file=sys.stderr);sys.exit(1)


if __name__=="__main__":main()
